using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Unity.Collections;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace DeVinciKart.EditorTools
{
    /// <summary>
    /// Génère la piste « Ancien campus → Nouveau campus » :
    ///   départ DANS l'ancien campus (hall intérieur) → pont au-dessus de la rivière → rond-point de la statue
    ///   → longe la Grande Arche (+ le Pouce) → arrivée sur le parvis du nouveau campus (podium + trophées).
    /// Menu : DeVinci Kart > Générer la piste Campus → Campus
    /// Toutes les cotes sont en mètres. Les réglages sont regroupés en haut du fichier.
    /// </summary>
    public static class CampusTrackGenerator
    {
        // ============================== RÉGLAGES ==============================
        const string ModelsFolder = "Assets/3DModels";
        const string GenFolder = "Assets/DeVinciKart/Generated";
        const string ScenePath = "Assets/Scenes/Piste_AncienCampus_NouveauCampus.unity";

        // Route
        const float RoadHalf = 6f;      // largeur de chaussée = 12 m
        const float CurbW = 1f;         // vibreurs
        const float BarrierT = 0.5f;    // épaisseur des barrières
        const float RoadLift = 0.06f;   // la route flotte un peu au-dessus du sol (évite le z-fighting)
        const float Step = 1f;          // échantillonnage de la spline

        // Bâtiments (échelle des modèles Tripo, normalisés à ~1 unité)
        static readonly Vector3 OldCampusPos = new Vector3(0f, -8.6f, 0f);   // socle de 8 m enterré
        const float OldCampusYaw = 180f, OldCampusScale = 100f;
        static readonly Vector3 NewCampusPos = new Vector3(0f, -2.5f, 850f);
        const float NewCampusYaw = 0f, NewCampusScale = 150f;
        static readonly Vector3 ArchPos = new Vector3(125f, 0f, 620f);
        const float ArchYaw = 0f, ArchScale = 110f;
        static readonly Vector3 StatueCenter = new Vector3(-25f, 0f, 420f);
        static readonly Vector3 PoucePos = new Vector3(15f, 0f, 615f);

        // Hall de départ, à l'intérieur du bâtiment de l'ancien campus (façade à z = 36.1)
        const float HallX0 = 1f, HallX1 = 19f, HallZ0 = 3f, HallZ1 = 36.6f, HallH = 10f;

        // Rivière + pont
        const float RiverZ0 = 197f, RiverZ1 = 273f, WaterY = -2.5f, BridgeX = 60f, DeckY = 6f;

        // Points de contrôle de la piste (x, hauteur, z). La hauteur est interpolée en douceur entre deux points.
        static readonly Vector3[] Ctrl =
        {
            new Vector3(10, 0, 4),    // fond du hall (départ)
            new Vector3(10, 0, 20),
            new Vector3(10, 0, 37),   // porte du hall / façade
            new Vector3(10, 0, 60),
            new Vector3(20, 0, 88),
            new Vector3(42, 0, 112),
            new Vector3(58, 0, 135),
            new Vector3(60, 0, 148),  // début de la rampe
            new Vector3(60, 6, 195),  // tablier du pont
            new Vector3(60, 6, 275),
            new Vector3(60, 0, 322),  // fin de la rampe
            new Vector3(58, 0, 340),
            new Vector3(45, 0, 362),
            new Vector3(20, 0, 380),
            new Vector3(-25, 0, 388), // rond-point de la statue (rayon 32 m)
            new Vector3(-47.6f, 0, 397.4f),
            new Vector3(-57, 0, 420),
            new Vector3(-47.6f, 0, 442.6f),
            new Vector3(-25, 0, 452),
            new Vector3(8, 0, 470),
            new Vector3(38, 0, 500),
            new Vector3(55, 0, 540),  // longue ligne droite le long de la Grande Arche
            new Vector3(55, 0, 600),
            new Vector3(55, 0, 655),
            new Vector3(48, 0, 700),
            new Vector3(22, 0, 730),
            new Vector3(4, 0, 752),
            new Vector3(0, 0, 772),   // parvis du nouveau campus
        };

        static readonly Vector3[] ItemBoxSpots = { new Vector3(12, 0, 72), new Vector3(52, 0, 350), new Vector3(24, 0, 487), new Vector3(53, 0, 690) };
        static readonly Vector3[] BoostSpots = { new Vector3(60, 6, 226), new Vector3(55, 0, 585), new Vector3(10, 0, 744) };
        // =====================================================================

        enum Zone { Hall, Bridge, Normal }

        class PathData
        {
            public readonly List<Vector3> p = new List<Vector3>();
            public readonly List<Vector3> fwd = new List<Vector3>();
            public readonly List<Vector3> right = new List<Vector3>();
            public readonly List<float> dist = new List<float>();
            public float length;
            public int Count => p.Count;

            public int Nearest(Vector3 q)
            {
                int best = 0; float bd = float.MaxValue;
                for (int i = 0; i < p.Count; i++)
                {
                    float d = (p[i] - q).sqrMagnitude;
                    if (d < bd) { bd = d; best = i; }
                }
                return best;
            }
        }

        static readonly Dictionary<string, Material> M = new Dictionary<string, Material>();
        static readonly List<string> Warnings = new List<string>();
        static Mesh cubeMesh, sphereMesh, cylMesh;
        static Font font;

        [MenuItem("DeVinci Kart/Générer la piste Campus → Campus")]
        public static void Generate()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            Warnings.Clear();
            M.Clear();
            try
            {
                EditorUtility.DisplayProgressBar("DeVinci Kart", "Préparation…", 0.05f);
                EnsureFolders();
                GrabPrimitiveMeshes();
                font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Textures et matériaux…", 0.1f);
                CreateMaterials();

                var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
                var root = new GameObject("Piste_Campus").transform;

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Tracé de la piste…", 0.2f);
                var path = BuildPath(Ctrl, Step);
                var trackGO = new GameObject("TrackPath");
                trackGO.transform.SetParent(root, false);
                var tp = trackGO.AddComponent<TrackPath>();
                tp.points = path.p.ToArray();
                tp.forwards = path.fwd.ToArray();
                tp.length = path.length;

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Route, vibreurs, barrières…", 0.3f);
                BuildRoad(path, root);

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Sol, rivière et pont…", 0.4f);
                BuildGroundAndRiver(root);
                BuildBridge(root);

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Hall de l'ancien campus…", 0.5f);
                var startLights = BuildHall(root);

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Import des modèles 3D (peut être long la 1re fois)…", 0.6f);
                PlaceLandmarks(path, root);

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Objets, boosts, checkpoints…", 0.75f);
                BuildItemBoxes(path, root);
                BuildBoostPads(path, root);
                var checkpoints = BuildCheckpoints(path, root, out int finishIdx);
                BuildFinish(path, finishIdx, root);
                BuildChevrons(path, root);

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Décor (arbres, lampadaires, tours)…", 0.85f);
                BuildDecor(path, root);

                EditorUtility.DisplayProgressBar("DeVinci Kart", "Kart, caméra, course…", 0.92f);
                var kart = BuildKart(new Vector3(7.5f, 0.3f, 25f), Quaternion.identity);
                var start = new GameObject("StartPoint").transform;
                start.SetParent(root, false);
                start.SetPositionAndRotation(new Vector3(7.5f, RoadLift, 25f), Quaternion.identity);

                var rmGO = new GameObject("RaceManager");
                var rm = rmGO.AddComponent<RaceManager>();
                rm.kart = kart;
                rm.checkpoints = checkpoints;
                rm.startLights = startLights;
                rm.startPoint = start;

                SetupCameraAndLighting(kart.transform);

                EditorSceneManager.SaveScene(scene, ScenePath);
                AddSceneToBuild(ScenePath);
                Selection.activeGameObject = kart.gameObject;

                string msg = $"Piste générée : {path.length:0} m, {checkpoints.Length} checkpoints.\nScène : {ScenePath}\n\n" +
                             "Lancez Play : ZQSD/flèches, Espace = dérapage, E = objet, R = replacer.";
                if (Warnings.Count > 0) msg += "\n\nAttention :\n- " + string.Join("\n- ", Warnings);
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("DeVinci Kart", msg, "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        // ------------------------------------------------------------------ utilitaires

        static void EnsureFolders()
        {
            foreach (var f in new[] { "Assets/DeVinciKart", GenFolder, GenFolder + "/Textures", GenFolder + "/Materials", GenFolder + "/Meshes" })
            {
                if (AssetDatabase.IsValidFolder(f)) continue;
                string parent = Path.GetDirectoryName(f).Replace('\\', '/');
                AssetDatabase.CreateFolder(parent, Path.GetFileName(f));
            }
        }

        static void GrabPrimitiveMeshes()
        {
            System.Func<PrimitiveType, Mesh> Grab = t =>
            {
                var g = GameObject.CreatePrimitive(t);
                var m = g.GetComponent<MeshFilter>().sharedMesh;
                Object.DestroyImmediate(g);
                return m;
            };
            cubeMesh = Grab(PrimitiveType.Cube);
            sphereMesh = Grab(PrimitiveType.Sphere);
            cylMesh = Grab(PrimitiveType.Cylinder);
        }

        static Zone ZoneAt(Vector3 p)
        {
            if (p.z < HallZ1 + 0.5f && p.z > HallZ0 - 1f && p.x > HallX0 - 1f && p.x < HallX1 + 1f) return Zone.Hall;
            if (Mathf.Abs(p.x - BridgeX) < 4f && p.z > 140f && p.z < 330f) return Zone.Bridge;
            return Zone.Normal;
        }

        static bool OverRiver(Vector3 p) => p.z > RiverZ0 + 0.5f && p.z < RiverZ1 - 0.5f;

        class MB
        {
            public readonly List<Vector3> v = new List<Vector3>();
            public readonly List<Vector2> uv = new List<Vector2>();
            public readonly List<int> t = new List<int>();

            public void Quad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector2 ua, Vector2 ub, Vector2 uc, Vector2 ud, Vector3 n)
            {
                int i = v.Count;
                v.Add(a); v.Add(b); v.Add(c); v.Add(d);
                uv.Add(ua); uv.Add(ub); uv.Add(uc); uv.Add(ud);
                Vector3 cr = Vector3.Cross(b - a, c - a);
                if (cr.sqrMagnitude < 1e-10f) cr = Vector3.Cross(c - a, d - a);
                if (Vector3.Dot(cr, n) >= 0f)
                {
                    t.Add(i); t.Add(i + 1); t.Add(i + 2);
                    t.Add(i); t.Add(i + 2); t.Add(i + 3);
                }
                else
                {
                    t.Add(i); t.Add(i + 2); t.Add(i + 1);
                    t.Add(i); t.Add(i + 3); t.Add(i + 2);
                }
            }

            void Face(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector3 n, int ax, int ay, float tile)
            {
                System.Func<Vector3, Vector2> U = q => new Vector2(q[ax] / tile, q[ay] / tile);
                Quad(a, b, c, d, U(a), U(b), U(c), U(d), n);
            }

            public void Box(Vector3 mn, Vector3 mx, float tile, bool bottom = true)
            {
                var a = new Vector3(mn.x, mn.y, mn.z); var b = new Vector3(mx.x, mn.y, mn.z);
                var c = new Vector3(mx.x, mn.y, mx.z); var d = new Vector3(mn.x, mn.y, mx.z);
                var e = new Vector3(mn.x, mx.y, mn.z); var f = new Vector3(mx.x, mx.y, mn.z);
                var g = new Vector3(mx.x, mx.y, mx.z); var h = new Vector3(mn.x, mx.y, mx.z);
                Face(e, f, g, h, Vector3.up, 0, 2, tile);
                if (bottom) Face(a, b, c, d, Vector3.down, 0, 2, tile);
                Face(a, b, f, e, Vector3.back, 0, 1, tile);
                Face(d, c, g, h, Vector3.forward, 0, 1, tile);
                Face(a, d, h, e, Vector3.left, 2, 1, tile);
                Face(b, c, g, f, Vector3.right, 2, 1, tile);
            }

            public bool Empty => v.Count == 0;

            public Mesh Build(string name)
            {
                var m = new Mesh { name = name, indexFormat = IndexFormat.UInt32 };
                m.SetVertices(v);
                m.SetUVs(0, uv);
                m.SetTriangles(t, 0);
                m.RecalculateNormals();
                m.RecalculateTangents();
                m.RecalculateBounds();
                return SaveMesh(m, name);
            }
        }

        static Mesh SaveMesh(Mesh m, string name)
        {
            string p = $"{GenFolder}/Meshes/{name}.asset";
            if (AssetDatabase.LoadAssetAtPath<Mesh>(p) != null) AssetDatabase.DeleteAsset(p);
            AssetDatabase.CreateAsset(m, p);
            return m;
        }

        static GameObject MeshGO(string name, Transform parent, MB mb, string mat, bool collider)
        {
            if (mb.Empty) return null;
            var mesh = mb.Build(name);
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            go.AddComponent<MeshRenderer>().sharedMaterial = M[mat];
            if (collider) go.AddComponent<MeshCollider>().sharedMesh = mesh;
            GameObjectUtility.SetStaticEditorFlags(go, StaticEditorFlags.BatchingStatic);
            return go;
        }

        static GameObject Prim(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale, string mat, Quaternion? rot = null, bool keepCollider = false)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localRotation = rot ?? Quaternion.identity;
            go.transform.localScale = scale;
            go.GetComponent<MeshRenderer>().sharedMaterial = M[mat];
            if (!keepCollider) Object.DestroyImmediate(go.GetComponent<Collider>());
            return go;
        }

        static GameObject Text3D(Transform parent, string text, Vector3 pos, Quaternion rot, float size, Color color)
        {
            var go = new GameObject("Texte_" + text.Replace("\n", " "));
            go.transform.SetParent(parent, false);
            go.transform.SetPositionAndRotation(pos, rot);
            var tm = go.AddComponent<TextMesh>();
            tm.text = text;
            tm.font = font;
            tm.fontSize = 96;
            tm.characterSize = size / 10f;
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            tm.color = color;
            go.GetComponent<MeshRenderer>().sharedMaterial = font.material;
            return go;
        }

        static void AddCombined(Dictionary<string, List<CombineInstance>> lists, string mat, Mesh mesh, Matrix4x4 m)
        {
            if (!lists.TryGetValue(mat, out var l)) lists[mat] = l = new List<CombineInstance>();
            l.Add(new CombineInstance { mesh = mesh, transform = m });
        }

        static void FlushCombined(Dictionary<string, List<CombineInstance>> lists, string prefix, Transform parent)
        {
            foreach (var kv in lists)
            {
                var mesh = new Mesh { name = prefix + "_" + kv.Key, indexFormat = IndexFormat.UInt32 };
                mesh.CombineMeshes(kv.Value.ToArray(), true, true);
                mesh.RecalculateBounds();
                SaveMesh(mesh, mesh.name);
                var go = new GameObject(mesh.name);
                go.transform.SetParent(parent, false);
                go.AddComponent<MeshFilter>().sharedMesh = mesh;
                go.AddComponent<MeshRenderer>().sharedMaterial = M[kv.Key];
                GameObjectUtility.SetStaticEditorFlags(go, StaticEditorFlags.BatchingStatic);
            }
        }

        // ------------------------------------------------------------------ spline

        static Vector3 CentripetalCR(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float u)
        {
            System.Func<Vector3, Vector3, float> K = (a, b) => Mathf.Max(Mathf.Sqrt(Vector3.Distance(a, b)), 1e-3f);
            float t0 = 0f, t1 = t0 + K(p0, p1), t2 = t1 + K(p1, p2), t3 = t2 + K(p2, p3);
            float t = Mathf.Lerp(t1, t2, u);
            Vector3 a1 = (t1 - t) / (t1 - t0) * p0 + (t - t0) / (t1 - t0) * p1;
            Vector3 a2 = (t2 - t) / (t2 - t1) * p1 + (t - t1) / (t2 - t1) * p2;
            Vector3 a3 = (t3 - t) / (t3 - t2) * p2 + (t - t2) / (t3 - t2) * p3;
            Vector3 b1 = (t2 - t) / (t2 - t0) * a1 + (t - t0) / (t2 - t0) * a2;
            Vector3 b2 = (t3 - t) / (t3 - t1) * a2 + (t - t1) / (t3 - t1) * a3;
            return (t2 - t) / (t2 - t1) * b1 + (t - t1) / (t2 - t1) * b2;
        }

        static PathData BuildPath(Vector3[] c, float step)
        {
            int n = c.Length;
            System.Func<Vector3, Vector3> Flat = v => new Vector3(v.x, 0f, v.z);
            var dense = new List<Vector3>();
            for (int i = 0; i < n - 1; i++)
            {
                Vector3 p0 = i == 0 ? 2f * c[0] - c[1] : c[i - 1];
                Vector3 p3 = i + 2 < n ? c[i + 2] : 2f * c[n - 1] - c[n - 2];
                const int sub = 60;
                for (int s = 0; s < sub; s++)
                {
                    float u = s / (float)sub;
                    Vector3 q = CentripetalCR(Flat(p0), Flat(c[i]), Flat(c[i + 1]), Flat(p3), u);
                    float sm = u * u * (3f - 2f * u);
                    q.y = Mathf.Lerp(c[i].y, c[i + 1].y, sm);
                    dense.Add(q);
                }
            }
            dense.Add(c[n - 1]);

            var pd = new PathData();
            pd.p.Add(dense[0]); pd.dist.Add(0f);
            float acc = 0f, target = step;
            for (int i = 1; i < dense.Count; i++)
            {
                Vector3 a = dense[i - 1], b = dense[i];
                float L = Vector3.Distance(a, b);
                if (L < 1e-6f) continue;
                while (acc + L >= target)
                {
                    pd.p.Add(Vector3.Lerp(a, b, (target - acc) / L));
                    pd.dist.Add(target);
                    target += step;
                }
                acc += L;
            }
            if ((pd.p[pd.p.Count - 1] - dense[dense.Count - 1]).magnitude > 0.2f)
            {
                pd.p.Add(dense[dense.Count - 1]);
                pd.dist.Add(acc);
            }
            pd.length = acc;

            for (int i = 0; i < pd.p.Count; i++)
            {
                Vector3 f = (pd.p[Mathf.Min(i + 1, pd.p.Count - 1)] - pd.p[Mathf.Max(i - 1, 0)]).normalized;
                Vector3 fFlat = new Vector3(f.x, 0f, f.z).normalized;
                pd.fwd.Add(f);
                pd.right.Add(Vector3.Cross(Vector3.up, fFlat).normalized);
            }
            return pd;
        }

        // ------------------------------------------------------------------ route

        static void BuildRoad(PathData path, Transform root)
        {
            var parent = new GameObject("Route").transform;
            parent.SetParent(root, false);
            int n = path.Count;
            const int chunk = 200;
            System.Func<int, float, Vector3> L = (i, off) => path.p[i] - path.right[i] * off + Vector3.up * RoadLift;
            System.Func<int, float, Vector3> R = (i, off) => path.p[i] + path.right[i] * off + Vector3.up * RoadLift;

            // Chaussée
            for (int c0 = 0, k = 0; c0 < n - 1; c0 += chunk, k++)
            {
                var mb = new MB();
                int c1 = Mathf.Min(c0 + chunk, n - 1);
                for (int i = c0; i < c1; i++)
                {
                    float v0 = path.dist[i] / 8f, v1 = path.dist[i + 1] / 8f;
                    mb.Quad(L(i, RoadHalf), L(i + 1, RoadHalf), R(i + 1, RoadHalf), R(i, RoadHalf),
                        new Vector2(0, v0), new Vector2(0, v1), new Vector2(1, v1), new Vector2(1, v0), Vector3.up);
                }
                MeshGO($"Chaussee_{k:00}", parent, mb, "Asphalt", true);
            }

            // Vibreurs / trottoirs, barrières, talus — par zones continues
            var curbN = new MB(); var curbB = new MB();
            var barN = new MB(); var barB = new MB(); var skirt = new MB();
            float o1 = RoadHalf + CurbW, o2 = o1 + BarrierT;

            for (int i = 0; i < n - 1; i++)
            {
                Zone z0 = ZoneAt(path.p[i]), z1 = ZoneAt(path.p[i + 1]);
                if (z0 == Zone.Hall || z1 == Zone.Hall) continue;
                bool bridge = z0 == Zone.Bridge;
                var curb = bridge ? curbB : curbN;
                var bar = bridge ? barB : barN;
                float hgt = bridge ? 1.2f : 1.0f;
                float lip = bridge ? 0.15f : 0.08f;
                float u0 = path.dist[i] / 4f, u1 = path.dist[i + 1] / 4f;

                foreach (int side in new[] { -1, 1 })
                {
                    System.Func<int, float, float, Vector3> P = (j, off, dy) => path.p[j] + path.right[j] * (side * off) + Vector3.up * (RoadLift + dy);
                    Vector3 outward = path.right[i] * side;

                    // vibreur (léger dévers, sans marche)
                    curb.Quad(P(i, RoadHalf, 0f), P(i + 1, RoadHalf, 0f), P(i + 1, o1, lip), P(i, o1, lip),
                        new Vector2(0, u0), new Vector2(0, u1), new Vector2(1, u1), new Vector2(1, u0), Vector3.up);

                    // barrière : face intérieure, dessus, face extérieure
                    float yb = -0.35f;
                    bar.Quad(P(i, o1, yb), P(i + 1, o1, yb), P(i + 1, o1, hgt), P(i, o1, hgt),
                        new Vector2(u0, 0), new Vector2(u1, 0), new Vector2(u1, 1), new Vector2(u0, 1), -outward);
                    bar.Quad(P(i, o1, hgt), P(i + 1, o1, hgt), P(i + 1, o2, hgt), P(i, o2, hgt),
                        new Vector2(u0, 0.95f), new Vector2(u1, 0.95f), new Vector2(u1, 1), new Vector2(u0, 1), Vector3.up);
                    bar.Quad(P(i, o2, yb), P(i + 1, o2, yb), P(i + 1, o2, hgt), P(i, o2, hgt),
                        new Vector2(u0, 0), new Vector2(u1, 0), new Vector2(u1, 1), new Vector2(u0, 1), outward);

                    // talus sous les rampes (hors rivière)
                    float y0 = path.p[i].y, y1 = path.p[i + 1].y;
                    if ((y0 > 0.1f || y1 > 0.1f) && !(bridge && OverRiver(path.p[i])))
                    {
                        Vector3 a = path.p[i] + path.right[i] * (side * o2); a.y = -0.3f;
                        Vector3 b = path.p[i + 1] + path.right[i + 1] * (side * o2); b.y = -0.3f;
                        Vector3 c = P(i + 1, o2, yb), d = P(i, o2, yb);
                        skirt.Quad(a, b, c, d, new Vector2(a.z / 4f, a.y / 4f), new Vector2(b.z / 4f, b.y / 4f),
                            new Vector2(c.z / 4f, c.y / 4f), new Vector2(d.z / 4f, d.y / 4f), outward);
                    }
                }
            }

            MeshGO("Vibreurs", parent, curbN, "Curb", true);
            MeshGO("Trottoirs_Pont", parent, curbB, "Concrete", true);
            MeshGO("Barrieres", parent, barN, "Barrier", true);
            MeshGO("Parapets_Pont", parent, barB, "Stone", true);
            MeshGO("Talus_Rampes", parent, skirt, "Stone", false);
        }

        // ------------------------------------------------------------------ sol / rivière / pont

        static void BuildGroundAndRiver(Transform root)
        {
            var parent = new GameObject("Sol_et_Riviere").transform;
            parent.SetParent(root, false);

            var south = new MB(); south.Box(new Vector3(-500, -6, -300), new Vector3(600, 0, RiverZ0), 8f, false);
            var southGO = MeshGO("Sol_Sud", parent, south, "Grass", false); southGO.AddComponent<BoxCollider>();
            var north = new MB(); north.Box(new Vector3(-500, -6, RiverZ1), new Vector3(600, 0, 1100), 8f, false);
            var northGO = MeshGO("Sol_Nord", parent, north, "Grass", false); northGO.AddComponent<BoxCollider>();

            var bed = new MB(); bed.Box(new Vector3(-500, -7, RiverZ0), new Vector3(600, -6, RiverZ1), 8f, false);
            MeshGO("Lit_Riviere", parent, bed, "Stone", false);

            var quays = new MB();
            quays.Box(new Vector3(-500, -6, RiverZ0 - 0.4f), new Vector3(600, 0.3f, RiverZ0 + 0.2f), 4f, false);
            quays.Box(new Vector3(-500, -6, RiverZ1 - 0.2f), new Vector3(600, 0.3f, RiverZ1 + 0.4f), 4f, false);
            MeshGO("Quais", parent, quays, "Stone", true);

            var water = new MB();
            Vector3 w0 = new Vector3(-500, WaterY, RiverZ0), w1 = new Vector3(600, WaterY, RiverZ0),
                    w2 = new Vector3(600, WaterY, RiverZ1), w3 = new Vector3(-500, WaterY, RiverZ1);
            water.Quad(w0, w1, w2, w3, new Vector2(w0.x, w0.z) / 20f, new Vector2(w1.x, w1.z) / 20f,
                new Vector2(w2.x, w2.z) / 20f, new Vector2(w3.x, w3.z) / 20f, Vector3.up);
            var waterGO = MeshGO("Eau", parent, water, "Water", false);
            GameObjectUtility.SetStaticEditorFlags(waterGO, 0);
            waterGO.AddComponent<UVScroller>().speed = new Vector2(0.02f, 0.01f);

            // Parvis (béton)
            var plazas = new MB();
            plazas.Box(new Vector3(-30, -0.1f, 36), new Vector3(45, 0.03f, 75), 6f, false);     // devant l'ancien campus
            plazas.Box(new Vector3(68, -0.1f, 552), new Vector3(185, 0.03f, 700), 6f, false);   // parvis de l'Arche
            plazas.Box(new Vector3(-85, -0.1f, 735), new Vector3(85, 0.03f, 800), 6f, false);   // parvis du nouveau campus
            plazas.Box(new Vector3(0, -0.1f, 600), new Vector3(32, 0.03f, 632), 6f, false);     // place du Pouce
            MeshGO("Parvis", parent, plazas, "Concrete", false);
        }

        static void BuildBridge(Transform root)
        {
            var parent = new GameObject("Pont").transform;
            parent.SetParent(root, false);
            float hb = RoadHalf + CurbW + BarrierT;     // 7.5 m
            float xL = BridgeX - hb, xR = BridgeX + hb;
            const float r = 8f, spring = -3.2f, deckTop = DeckY + RoadLift;
            var spans = new[] { (RiverZ0, RiverZ0 + 16f), (217f, 233f), (237f, 253f), (257f, RiverZ1) };

            var stone = new MB();
            foreach (var span in spans)
            {
                float zs = span.Item1, ze = span.Item2;
                float zc = (zs + ze) * 0.5f;
                const int seg = 24;
                System.Func<float, float> ArchY = z => spring + Mathf.Sqrt(Mathf.Max(0f, r * r - (z - zc) * (z - zc)));
                for (int s = 0; s < seg; s++)
                {
                    float za = Mathf.Lerp(zs, ze, s / (float)seg), zb = Mathf.Lerp(zs, ze, (s + 1) / (float)seg);
                    float ya = ArchY(za), yb = ArchY(zb);
                    // tympans (deux côtés)
                    foreach (float x in new[] { xL, xR })
                    {
                        Vector3 n = x < BridgeX ? Vector3.left : Vector3.right;
                        Vector3 a = new Vector3(x, ya, za), b = new Vector3(x, yb, zb), c = new Vector3(x, deckTop, zb), d = new Vector3(x, deckTop, za);
                        stone.Quad(a, b, c, d, new Vector2(za, ya) / 4f, new Vector2(zb, yb) / 4f, new Vector2(zb, deckTop) / 4f, new Vector2(za, deckTop) / 4f, n);
                    }
                    // intrados (voûte)
                    Vector3 mid = new Vector3(BridgeX, (ya + yb) * 0.5f, (za + zb) * 0.5f);
                    Vector3 toCenter = new Vector3(0f, spring - mid.y, zc - mid.z);
                    stone.Quad(new Vector3(xL, ya, za), new Vector3(xR, ya, za), new Vector3(xR, yb, zb), new Vector3(xL, yb, zb),
                        new Vector2(xL, za) / 4f, new Vector2(xR, za) / 4f, new Vector2(xR, zb) / 4f, new Vector2(xL, zb) / 4f, toCenter);
                }
            }
            // piles
            foreach (float zp in new[] { 213f, 233f, 253f })
            {
                stone.Box(new Vector3(xL - 0.5f, -6f, zp), new Vector3(xR + 0.5f, deckTop - 0.02f, zp + 4f), 4f, false);
                // avant-becs
                stone.Box(new Vector3(xL - 2.5f, -6f, zp + 0.5f), new Vector3(xL - 0.5f, 1.5f, zp + 3.5f), 4f, false);
                stone.Box(new Vector3(xR + 0.5f, -6f, zp + 0.5f), new Vector3(xR + 2.5f, 1.5f, zp + 3.5f), 4f, false);
            }
            MeshGO("Pont_Pierre", parent, stone, "Stone", false);

            // lampadaires du pont
            var lists = new Dictionary<string, List<CombineInstance>>();
            float top = deckTop + 1.2f;
            foreach (float z in new[] { 199f, 215f, 235f, 255f, 271f })
            foreach (float x in new[] { BridgeX - (RoadHalf + CurbW + BarrierT * 0.5f), BridgeX + (RoadHalf + CurbW + BarrierT * 0.5f) })
            {
                AddCombined(lists, "DarkMetal", cylMesh, Matrix4x4.TRS(new Vector3(x, top + 2.2f, z), Quaternion.identity, new Vector3(0.18f, 2.2f, 0.18f)));
                AddCombined(lists, "LampHead", sphereMesh, Matrix4x4.TRS(new Vector3(x, top + 4.6f, z), Quaternion.identity, Vector3.one * 0.7f));
            }
            FlushCombined(lists, "Pont_Lampadaires", parent);
            Text3D(parent, "PONT DE LA RIVIÈRE", new Vector3(BridgeX, DeckY + 9f, 196f), Quaternion.identity, 1.4f, Color.white);
        }

        // ------------------------------------------------------------------ hall intérieur (départ)

        static Renderer[] BuildHall(Transform root)
        {
            var parent = new GameObject("Hall_AncienCampus").transform;
            parent.SetParent(root, false);
            float cx = (HallX0 + HallX1) * 0.5f;

            var floor = new MB(); floor.Box(new Vector3(HallX0 - 0.5f, -0.5f, HallZ0 - 0.5f), new Vector3(HallX1 + 0.5f, 0.02f, HallZ1 + 1.2f), 4f, false);
            MeshGO("Hall_Sol", parent, floor, "Tiles", true);

            var walls = new MB();
            walls.Box(new Vector3(HallX0 - 0.5f, 0, HallZ0 - 0.5f), new Vector3(HallX0, HallH, HallZ1), 10f);      // mur gauche
            walls.Box(new Vector3(HallX1, 0, HallZ0 - 0.5f), new Vector3(HallX1 + 0.5f, HallH, HallZ1), 10f);      // mur droit
            walls.Box(new Vector3(HallX0 - 0.5f, 0, HallZ0 - 0.5f), new Vector3(HallX1 + 0.5f, HallH, HallZ0), 10f); // fond
            MeshGO("Hall_Murs", parent, walls, "HallWall", true);

            var ceil = new MB(); ceil.Box(new Vector3(HallX0 - 0.5f, HallH, HallZ0 - 0.5f), new Vector3(HallX1 + 0.5f, HallH + 0.5f, HallZ1), 6f);
            MeshGO("Hall_Plafond", parent, ceil, "Concrete", false);

            // piliers
            var pillars = new MB();
            for (float z = HallZ0 + 4f; z < HallZ1 - 1f; z += 6f)
            {
                pillars.Box(new Vector3(HallX0, 0, z - 0.4f), new Vector3(HallX0 + 0.6f, HallH, z + 0.4f), 4f, false);
                pillars.Box(new Vector3(HallX1 - 0.6f, 0, z - 0.4f), new Vector3(HallX1, HallH, z + 0.4f), 4f, false);
            }
            MeshGO("Hall_Piliers", parent, pillars, "DarkMetal", false);

            // éclairage : bandeaux lumineux + 3 lumières
            var panels = new MB();
            for (float z = HallZ0 + 3f; z < HallZ1 - 1f; z += 5f)
                panels.Box(new Vector3(cx - 4f, HallH - 0.15f, z - 0.4f), new Vector3(cx + 4f, HallH, z + 0.4f), 4f);
            MeshGO("Hall_Lumieres", parent, panels, "LightPanel", false);
            foreach (float z in new[] { 9f, 20f, 31f })
            {
                var lg = new GameObject("Lumiere_Hall");
                lg.transform.SetParent(parent, false);
                lg.transform.position = new Vector3(cx, HallH - 1.5f, z);
                var l = lg.AddComponent<Light>();
                l.type = LightType.Point;
                l.range = 22f;
                l.intensity = 3f;
                l.color = new Color(1f, 0.95f, 0.88f);
            }

            // porte / portique dans la façade
            var portal = new MB();
            portal.Box(new Vector3(HallX0 - 1.5f, 0, HallZ1 - 0.3f), new Vector3(HallX0 + 0.5f, HallH + 3f, HallZ1 + 1.3f), 4f);
            portal.Box(new Vector3(HallX1 - 0.5f, 0, HallZ1 - 0.3f), new Vector3(HallX1 + 1.5f, HallH + 3f, HallZ1 + 1.3f), 4f);
            portal.Box(new Vector3(HallX0 - 1.5f, HallH, HallZ1 - 0.3f), new Vector3(HallX1 + 1.5f, HallH + 3f, HallZ1 + 1.3f), 4f);
            MeshGO("Portique_Sortie", parent, portal, "Brand", true);
            Text3D(parent, "ANCIEN CAMPUS", new Vector3(cx, HallH + 1.5f, HallZ1 - 0.4f), Quaternion.identity, 1.3f, Color.white);
            Text3D(parent, "ANCIEN CAMPUS", new Vector3(cx, HallH + 1.5f, HallZ1 + 1.4f), Quaternion.Euler(0, 180, 0), 1.3f, Color.white);

            // déco murale
            Text3D(parent, "DEVINCI KART", new Vector3(HallX0 + 0.05f, 6.5f, 14f), Quaternion.Euler(0, -90, 0), 1.2f, new Color(0.3f, 0.85f, 1f));
            Text3D(parent, "PÔLE LÉONARD DE VINCI", new Vector3(HallX1 - 0.05f, 6.5f, 14f), Quaternion.Euler(0, 90, 0), 0.9f, new Color(1f, 0.85f, 0.3f));
            Text3D(parent, "ESILV", new Vector3(HallX0 + 0.05f, 6.5f, 27f), Quaternion.Euler(0, -90, 0), 1.4f, Color.white);
            Text3D(parent, "ESILV", new Vector3(HallX1 - 0.05f, 6.5f, 27f), Quaternion.Euler(0, 90, 0), 1.4f, Color.white);

            // grille de départ (8 places)
            var grid = new MB();
            for (int s = 0; s < 8; s++)
            {
                float x = s % 2 == 0 ? cx - 2.5f : cx + 2.5f;
                float z = 25f - (s / 2) * 4f - (s % 2) * 2f;
                grid.Box(new Vector3(x - 1.3f, 0.07f, z + 1.2f), new Vector3(x + 1.3f, 0.08f, z + 1.45f), 4f, false);
            }
            MeshGO("Grille_Depart", parent, grid, "White", false);
            var line = new MB();
            Vector3 l0 = new Vector3(cx - RoadHalf, 0.075f, 28f), l1 = new Vector3(cx + RoadHalf, 0.075f, 28f),
                    l2 = new Vector3(cx + RoadHalf, 0.075f, 29.5f), l3 = new Vector3(cx - RoadHalf, 0.075f, 29.5f);
            line.Quad(l0, l1, l2, l3, new Vector2(0, 0), new Vector2(8, 0), new Vector2(8, 1), new Vector2(0, 1), Vector3.up);
            MeshGO("Ligne_Depart", parent, line, "Checker", false);

            // portique des feux
            var gantry = new MB();
            gantry.Box(new Vector3(cx - 7f, 6.6f, 30.4f), new Vector3(cx + 7f, 7.6f, 31f), 4f);
            gantry.Box(new Vector3(cx - 7.2f, 0f, 30.4f), new Vector3(cx - 6.6f, 7.6f, 31f), 4f);
            gantry.Box(new Vector3(cx + 6.6f, 0f, 30.4f), new Vector3(cx + 7.2f, 7.6f, 31f), 4f);
            MeshGO("Portique_Feux", parent, gantry, "DarkMetal", false);
            var lights = new List<Renderer>();
            for (int i = 0; i < 3; i++)
            {
                var s = Prim(PrimitiveType.Sphere, $"Feu_{i + 1}", parent, new Vector3(cx - 1.6f + i * 1.6f, 6.1f, 30.3f), Vector3.one * 1.1f, "StartLight");
                lights.Add(s.GetComponent<Renderer>());
            }
            Text3D(parent, "DÉPART", new Vector3(cx, 8.4f, 30.35f), Quaternion.identity, 1.1f, Color.white);
            return lights.ToArray();
        }

        // ------------------------------------------------------------------ modèles 3D

        static string Simplify(string s)
        {
            var sb = new StringBuilder();
            foreach (char ch in s.Normalize(NormalizationForm.FormD))
                if (CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark && char.IsLetterOrDigit(ch))
                    sb.Append(char.ToLowerInvariant(ch));
            return sb.ToString();
        }

        static GameObject FindModel(string key)
        {
            if (!Directory.Exists(ModelsFolder)) return null;
            string want = Simplify(key);
            foreach (var file in Directory.GetFiles(ModelsFolder, "*.glb"))
            {
                if (Simplify(Path.GetFileNameWithoutExtension(file)) != want) continue;
                string ap = file.Replace('\\', '/');
                var go = AssetDatabase.LoadAssetAtPath<GameObject>(ap);
                if (go == null)
                {
                    AssetDatabase.ImportAsset(ap, ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
                    go = AssetDatabase.LoadAssetAtPath<GameObject>(ap);
                }
                return go;
            }
            return null;
        }

        static GameObject InstantiateModel(string key, Transform parent, float approxSize)
        {
            var prefab = FindModel(key);
            if (prefab != null)
                return (GameObject)PrefabUtility.InstantiatePrefab(prefab, parent);

            Warnings.Add($"Modèle « {key} » introuvable ou non importé (installez glTFast) → cube de remplacement.");
            var ph = GameObject.CreatePrimitive(PrimitiveType.Cube);
            ph.name = key + " (MANQUANT)";
            ph.transform.SetParent(parent, false);
            Object.DestroyImmediate(ph.GetComponent<Collider>());
            ph.GetComponent<MeshRenderer>().sharedMaterial = M["Missing"];
            var holder = new GameObject(key + "_placeholder");
            holder.transform.SetParent(parent, false);
            ph.transform.SetParent(holder.transform, false);
            ph.transform.localPosition = new Vector3(0, 0.5f, 0);
            ph.transform.localScale = new Vector3(0.9f, 1f, 0.9f);
            return holder;
        }

        static GameObject PlaceScaled(string key, Transform parent, Vector3 pos, float yaw, float scale)
        {
            var go = InstantiateModel(key, parent, 1f);
            go.transform.SetPositionAndRotation(pos, Quaternion.Euler(0, yaw, 0));
            go.transform.localScale = Vector3.one * scale;
            return go;
        }

        static Bounds WorldBounds(GameObject go)
        {
            var rs = go.GetComponentsInChildren<Renderer>();
            if (rs.Length == 0) return new Bounds(go.transform.position, Vector3.one);
            var b = rs[0].bounds;
            foreach (var r in rs) b.Encapsulate(r.bounds);
            return b;
        }

        /// <summary>Place un modèle en le mettant à la hauteur voulue, posé (centre bas) sur groundPos.</summary>
        static GameObject PlaceFit(string key, Transform parent, Vector3 groundPos, float yaw, float height)
        {
            var go = InstantiateModel(key, parent, height);
            go.transform.SetPositionAndRotation(Vector3.zero, Quaternion.Euler(0, yaw, 0));
            go.transform.localScale = Vector3.one;
            var b = WorldBounds(go);
            float s = height / Mathf.Max(b.size.y, 1e-4f);
            go.transform.localScale = Vector3.one * s;
            b = WorldBounds(go);
            go.transform.position += groundPos - new Vector3(b.center.x, b.min.y, b.center.z);
            return go;
        }

        static int CountVertsIn(GameObject model, Bounds box)
        {
            int count = 0;
            foreach (var mf in model.GetComponentsInChildren<MeshFilter>())
            {
                if (mf.sharedMesh == null) continue;
                Matrix4x4 l2w = mf.transform.localToWorldMatrix;
                using (var arr = Mesh.AcquireReadOnlyMeshData(mf.sharedMesh))
                {
                    var d = arr[0];
                    var pos = new NativeArray<Vector3>(d.vertexCount, Allocator.Temp);
                    d.GetVertices(pos);
                    for (int i = 0; i < pos.Length; i++)
                        if (box.Contains(l2w.MultiplyPoint3x4(pos[i]))) count++;
                    pos.Dispose();
                }
            }
            return count;
        }

        /// <summary>Copie les meshes du modèle en retirant les triangles qui touchent la boîte (coordonnées monde).</summary>
        static void CutHole(GameObject model, Bounds box, string name)
        {
            int k = 0;
            foreach (var mf in model.GetComponentsInChildren<MeshFilter>())
            {
                var src = mf.sharedMesh;
                if (src == null) continue;
                Matrix4x4 l2w = mf.transform.localToWorldMatrix;
                using (var arr = Mesh.AcquireReadOnlyMeshData(src))
                {
                    var d = arr[0];
                    int vc = d.vertexCount;
                    var pos = new NativeArray<Vector3>(vc, Allocator.Temp);
                    d.GetVertices(pos);
                    var inside = new bool[vc];
                    int nIn = 0;
                    for (int i = 0; i < vc; i++)
                        if (box.Contains(l2w.MultiplyPoint3x4(pos[i]))) { inside[i] = true; nIn++; }
                    if (nIn == 0) { pos.Dispose(); continue; }

                    var mesh = new Mesh { name = $"{name}_{k}", indexFormat = IndexFormat.UInt32 };
                    mesh.SetVertices(pos);
                    if (d.HasVertexAttribute(VertexAttribute.Normal))
                    {
                        var nor = new NativeArray<Vector3>(vc, Allocator.Temp); d.GetNormals(nor); mesh.SetNormals(nor); nor.Dispose();
                    }
                    if (d.HasVertexAttribute(VertexAttribute.Tangent))
                    {
                        var tan = new NativeArray<Vector4>(vc, Allocator.Temp); d.GetTangents(tan); mesh.SetTangents(tan); tan.Dispose();
                    }
                    if (d.HasVertexAttribute(VertexAttribute.TexCoord0))
                    {
                        var uv = new NativeArray<Vector2>(vc, Allocator.Temp); d.GetUVs(0, uv); mesh.SetUVs(0, uv); uv.Dispose();
                    }
                    if (d.HasVertexAttribute(VertexAttribute.Color))
                    {
                        var col = new NativeArray<Color>(vc, Allocator.Temp); d.GetColors(col); mesh.SetColors(col); col.Dispose();
                    }
                    mesh.subMeshCount = d.subMeshCount;
                    for (int s = 0; s < d.subMeshCount; s++)
                    {
                        var sm = d.GetSubMesh(s);
                        var idx = new NativeArray<int>(sm.indexCount, Allocator.Temp);
                        d.GetIndices(idx, s);
                        var keep = new List<int>(sm.indexCount);
                        for (int t = 0; t + 2 < idx.Length; t += 3)
                        {
                            int a = idx[t], b = idx[t + 1], c = idx[t + 2];
                            if (inside[a] || inside[b] || inside[c]) continue;
                            keep.Add(a); keep.Add(b); keep.Add(c);
                        }
                        mesh.SetTriangles(keep, s, false);
                        idx.Dispose();
                    }
                    pos.Dispose();
                    mesh.RecalculateBounds();
                    mf.sharedMesh = SaveMesh(mesh, mesh.name);
                    k++;
                }
            }
            if (k == 0) Warnings.Add("Aucun triangle trouvé dans le volume du hall : vérifiez la position de l'ancien campus.");
        }

        static void PlaceLandmarks(PathData path, Transform root)
        {
            var parent = new GameObject("Monuments").transform;
            parent.SetParent(root, false);

            var oldCampus = PlaceScaled("AncienCampus", parent, OldCampusPos, OldCampusYaw, OldCampusScale);
            oldCampus.name = "Ancien Campus";
            // On évide le volume du hall dans le bâtiment (façade comprise) pour que la porte soit vraiment ouverte.
            var hallBox = new Bounds();
            hallBox.SetMinMax(new Vector3(HallX0 - 0.4f, -1f, HallZ0 - 0.6f), new Vector3(HallX1 + 0.4f, HallH + 0.4f, HallZ1 + 1f));
            EditorUtility.DisplayProgressBar("DeVinci Kart", "Ouverture de la porte dans la façade de l'ancien campus…", 0.65f);
            // Contrôle : la façade doit se trouver en z ≈ 36 pour x ∈ [1, 19]. Si on la trouve côté x négatif, le modèle est en miroir.
            var facade = new Bounds(); facade.SetMinMax(new Vector3(HallX0, 0.5f, HallZ1 - 1.2f), new Vector3(HallX1, 9f, HallZ1 + 0.2f));
            var mirror = new Bounds(); mirror.SetMinMax(new Vector3(-HallX1, 0.5f, HallZ1 - 1.2f), new Vector3(-HallX0, 9f, HallZ1 + 0.2f));
            int direct = CountVertsIn(oldCampus, facade), mirrored = CountVertsIn(oldCampus, mirror);
            if (mirrored > 3 * Mathf.Max(direct, 1))
            {
                var sc = oldCampus.transform.localScale;
                oldCampus.transform.localScale = new Vector3(-sc.x, sc.y, sc.z);
                Debug.Log($"[DeVinci Kart] Ancien campus importé en miroir ({direct} / {mirrored} sommets) → corrigé.");
            }
            else if (direct < 50)
                Warnings.Add($"Façade de l'ancien campus non trouvée à l'endroit prévu ({direct} sommets) : vérifiez OldCampusPos / OldCampusYaw.");
            CutHole(oldCampus, hallBox, "AncienCampus_Evide");
            PlaceScaled("ESILV_NouveauCampus3D", parent, NewCampusPos, NewCampusYaw, NewCampusScale).name = "Nouveau Campus";
            PlaceScaled("ArcheLaDefenseModel", parent, ArchPos, ArchYaw, ArchScale).name = "Grande Arche";

            // Rond-point de la statue
            Prim(PrimitiveType.Cylinder, "RondPoint_Bordure", parent, StatueCenter + Vector3.up * 0.1f, new Vector3(41f, 0.2f, 41f), "Stone");
            Prim(PrimitiveType.Cylinder, "RondPoint_Pelouse", parent, StatueCenter + Vector3.up * 0.25f, new Vector3(39f, 0.1f, 39f), "Grass");
            Prim(PrimitiveType.Cylinder, "Piedestal", parent, StatueCenter + Vector3.up * 2.3f, new Vector3(7f, 2f, 7f), "Stone");
            Prim(PrimitiveType.Cylinder, "Piedestal_Haut", parent, StatueCenter + Vector3.up * 4.45f, new Vector3(8f, 0.15f, 8f), "Concrete");
            var statue = PlaceFit("StatueAnge", parent, StatueCenter + Vector3.up * 4.6f, 160f, 11f);
            statue.name = "Statue Ange";

            // Le Pouce, de l'autre côté de la ligne droite de l'Arche
            Prim(PrimitiveType.Cube, "Pouce_Socle", parent, PoucePos + Vector3.up * 0.5f, new Vector3(5f, 1f, 5f), "Concrete");
            PlaceFit("LePouceModele3d", parent, PoucePos + Vector3.up * 1f, 70f, 12f).name = "Le Pouce";

            // Lakitu au-dessus de la grille de départ
            var lakitu = PlaceFit("Lakitu", parent, new Vector3(15f, 5f, 31.5f), 180f, 2.2f);
            lakitu.name = "Lakitu";
            var bobHolder = new GameObject("Lakitu_Flottement").transform;
            bobHolder.SetParent(parent, false);
            lakitu.transform.SetParent(bobHolder, true);
            var sp = bobHolder.gameObject.AddComponent<Spinner>();
            sp.degreesPerSecond = Vector3.zero;
            sp.bobAmplitude = 0.25f;
            sp.bobFrequency = 0.4f;
        }

        // ------------------------------------------------------------------ objets, boosts, checkpoints

        static void BuildItemBoxes(PathData path, Transform root)
        {
            var parent = new GameObject("Boites_Objets").transform;
            parent.SetParent(root, false);
            int k = 0;
            foreach (var spot in ItemBoxSpots)
            {
                int i = path.Nearest(spot);
                foreach (float off in new[] { -4.5f, -1.5f, 1.5f, 4.5f })
                {
                    Vector3 pos = path.p[i] + path.right[i] * off + Vector3.up * 1.3f;
                    var box = new GameObject($"BoiteObjet_{k++:00}");
                    box.transform.SetParent(parent, false);
                    box.transform.SetPositionAndRotation(pos, Quaternion.LookRotation(path.fwd[i]));
                    var col = box.AddComponent<BoxCollider>();
                    col.isTrigger = true;
                    col.size = Vector3.one * 1.8f;
                    box.AddComponent<ItemBox>();

                    var vis = Prim(PrimitiveType.Cube, "Visuel", box.transform, Vector3.zero, Vector3.one * 1.1f, "Rainbow");
                    var spin = vis.AddComponent<Spinner>();
                    spin.degreesPerSecond = new Vector3(0, 70, 0);
                    spin.bobAmplitude = 0.15f;
                    spin.bobFrequency = 0.6f;
                    var q1 = Text3D(vis.transform, "?", Vector3.zero, Quaternion.identity, 0.9f, Color.white);
                    q1.transform.localPosition = new Vector3(0, 0, -0.51f);
                    q1.transform.localScale = Vector3.one / 1.1f;
                    var q2 = Text3D(vis.transform, "?", Vector3.zero, Quaternion.identity, 0.9f, Color.white);
                    q2.transform.localPosition = new Vector3(0, 0, 0.51f);
                    q2.transform.localRotation = Quaternion.Euler(0, 180, 0);
                    q2.transform.localScale = Vector3.one / 1.1f;
                }
            }
        }

        static void BuildBoostPads(PathData path, Transform root)
        {
            var parent = new GameObject("Boosts").transform;
            parent.SetParent(root, false);
            var mb = new MB();
            foreach (var spot in BoostSpots)
            {
                int c = path.Nearest(spot);
                int a = Mathf.Max(0, c - 3), b = Mathf.Min(path.Count - 1, c + 3);
                for (int i = a; i < b; i++)
                {
                    float v0 = (i - a) / 6f, v1 = (i + 1 - a) / 6f;
                    Vector3 up = Vector3.up * (RoadLift + 0.02f);
                    mb.Quad(path.p[i] - path.right[i] * 2.5f + up, path.p[i + 1] - path.right[i + 1] * 2.5f + up,
                        path.p[i + 1] + path.right[i + 1] * 2.5f + up, path.p[i] + path.right[i] * 2.5f + up,
                        new Vector2(0, v0), new Vector2(0, v1), new Vector2(1, v1), new Vector2(1, v0), Vector3.up);
                }
                var trig = new GameObject("Boost_Trigger");
                trig.transform.SetParent(parent, false);
                trig.transform.SetPositionAndRotation(path.p[c], Quaternion.LookRotation(path.fwd[c]));
                var col = trig.AddComponent<BoxCollider>();
                col.isTrigger = true;
                col.center = new Vector3(0, 1f, 0);
                col.size = new Vector3(5f, 2f, 6f);
                trig.AddComponent<BoostPad>();
            }
            MeshGO("Boost_Plaques", parent, mb, "Boost", false);
        }

        static Checkpoint[] BuildCheckpoints(PathData path, Transform root, out int finishIdx)
        {
            var parent = new GameObject("Checkpoints").transform;
            parent.SetParent(root, false);
            finishIdx = path.Count - 1 - 12;
            var idx = new List<int>();
            for (int i = 60; i < finishIdx - 30; i += 60) idx.Add(i);
            idx.Add(finishIdx);
            var list = new List<Checkpoint>();
            for (int k = 0; k < idx.Count; k++)
            {
                int i = idx[k];
                var go = new GameObject(k == idx.Count - 1 ? "Checkpoint_ARRIVEE" : $"Checkpoint_{k:00}");
                go.transform.SetParent(parent, false);
                Vector3 f = path.fwd[i]; f.y = 0;
                go.transform.SetPositionAndRotation(path.p[i] + Vector3.up * RoadLift, Quaternion.LookRotation(f.normalized));
                var col = go.AddComponent<BoxCollider>();
                col.isTrigger = true;
                col.center = new Vector3(0, 2.5f, 0);
                col.size = new Vector3(2f * (RoadHalf + CurbW + 1f), 6f, 2f);
                var cp = go.AddComponent<Checkpoint>();
                cp.index = k;
                cp.isFinish = k == idx.Count - 1;
                list.Add(cp);
            }
            return list.ToArray();
        }

        static void BuildFinish(PathData path, int fi, Transform root)
        {
            var parent = new GameObject("Arrivee_NouveauCampus").transform;
            parent.SetParent(root, false);
            Vector3 p = path.p[fi], r = path.right[fi];
            Vector3 f = path.fwd[fi]; f.y = 0; f.Normalize();

            var line = new MB();
            Vector3 up = Vector3.up * (RoadLift + 0.015f);
            line.Quad(p - r * RoadHalf + up, p - r * RoadHalf + f * 1.5f + up, p + r * RoadHalf + f * 1.5f + up, p + r * RoadHalf + up,
                new Vector2(0, 0), new Vector2(0, 1), new Vector2(8, 1), new Vector2(8, 0), Vector3.up);
            MeshGO("Ligne_Arrivee", parent, line, "Checker", false);

            var gantry = new GameObject("Portique_Arrivee").transform;
            gantry.SetParent(parent, false);
            gantry.SetPositionAndRotation(p, Quaternion.LookRotation(f));
            float w = RoadHalf + CurbW + BarrierT + 1f;
            Prim(PrimitiveType.Cube, "Pilier_G", gantry, new Vector3(-w, 4f, 0), new Vector3(1f, 8f, 1f), "DarkMetal", null, true);
            Prim(PrimitiveType.Cube, "Pilier_D", gantry, new Vector3(w, 4f, 0), new Vector3(1f, 8f, 1f), "DarkMetal", null, true);
            Prim(PrimitiveType.Cube, "Banniere", gantry, new Vector3(0, 8.2f, 0), new Vector3(2f * w + 1f, 1.8f, 0.6f), "Checker");
            var finTxt = Text3D(gantry, "ARRIVÉE · NOUVEAU CAMPUS", Vector3.zero, Quaternion.identity, 1.2f, Color.white);
            finTxt.transform.localPosition = new Vector3(0, 10f, -0.1f);
            finTxt.transform.localRotation = Quaternion.identity;

            // podium + trophées, à gauche de la ligne
            var podium = new GameObject("Podium").transform;
            podium.SetParent(parent, false);
            podium.SetPositionAndRotation(p - r * (w + 9f) + f * 6f, Quaternion.LookRotation(-r));
            var steps = new[] { (0f, 1.5f, "1", "TrophePremier"), (-2.4f, 1.0f, "2", "Trophe2eme"), (2.4f, 0.7f, "3", "Trophe3eme") };
            foreach (var st in steps)
            {
                float x = st.Item1, h = st.Item2;
                string num = st.Item3, model = st.Item4;
                Prim(PrimitiveType.Cube, "Marche_" + num, podium, new Vector3(x, h / 2f, 0), new Vector3(2.3f, h, 2f), "White", null, true);
                var t = Text3D(podium, num, Vector3.zero, Quaternion.identity, 0.8f, new Color(0.1f, 0.2f, 0.5f));
                t.transform.localPosition = new Vector3(x, h / 2f, -1.02f);
                t.transform.localRotation = Quaternion.identity;
                var tr = PlaceFit(model, podium, podium.TransformPoint(new Vector3(x, h, 0)), podium.eulerAngles.y + 180f, 1.3f);
                var spin = tr.AddComponent<Spinner>();
                spin.degreesPerSecond = new Vector3(0, 30, 0);
            }
        }

        static void BuildChevrons(PathData path, Transform root)
        {
            var parent = new GameObject("Panneaux_Virage").transform;
            parent.SetParent(root, false);
            var boards = new MB(); var posts = new MB();
            float off = RoadHalf + CurbW + BarrierT + 1.2f;
            for (int i = 0; i < path.Count; i += 7)
            {
                Vector3 p = path.p[i];
                Vector3 toP = new Vector3(p.x - StatueCenter.x, 0, p.z - StatueCenter.z);
                if (toP.magnitude > 45f) continue;
                Vector3 outDir = toP.normalized;
                Vector3 a = path.fwd[i]; a.y = 0; a.Normalize();
                Vector3 c = p + outDir * off + Vector3.up * 1.9f;
                Vector3 h = a * 1.5f, v = Vector3.up * 0.6f;
                boards.Quad(c - h - v, c + h - v, c + h + v, c - h + v, new Vector2(0, 0), new Vector2(1, 0), new Vector2(1, 1), new Vector2(0, 1), -outDir);
                Vector3 back = outDir * 0.05f;
                posts.Quad(c - h - v + back, c + h - v + back, c + h + v + back, c - h + v + back,
                    Vector2.zero, Vector2.right, Vector2.one, Vector2.up, outDir);
                Vector3 pb = p + outDir * (off + 0.1f);
                posts.Box(pb + new Vector3(-0.08f, 0, -0.08f), pb + new Vector3(0.08f, 1.4f, 0.08f), 2f);
            }
            MeshGO("Chevrons", parent, boards, "Chevron", false);
            MeshGO("Chevrons_Supports", parent, posts, "DarkMetal", false);
        }

        // ------------------------------------------------------------------ décor

        static void BuildDecor(PathData path, Transform root)
        {
            var parent = new GameObject("Decor").transform;
            parent.SetParent(root, false);
            var rng = new System.Random(42);
            System.Func<float, float, float> R = (a, b) => a + (float)rng.NextDouble() * (b - a);

            var coarse = new List<Vector2>();
            for (int i = 0; i < path.Count; i += 4) coarse.Add(new Vector2(path.p[i].x, path.p[i].z));
            System.Func<float, float, float, bool> NearRoad = (x, z, d) =>
            {
                float d2 = d * d;
                foreach (var c in coarse) if ((c.x - x) * (c.x - x) + (c.y - z) * (c.y - z) < d2) return true;
                return false;
            };
            System.Func<float, float, bool> Blocked = (x, z) =>
            {
                if (z > RiverZ0 - 10f && z < RiverZ1 + 10f) return true;
                if (x > -60 && x < 60 && z > -45 && z < 78) return true;          // ancien campus + parvis
                if (x > -90 && x < 90 && z > 728 && z < 935) return true;         // nouveau campus
                if (x > 62 && x < 192 && z > 545 && z < 705) return true;         // Arche
                if (new Vector2(x - StatueCenter.x, z - StatueCenter.z).magnitude < 26f) return true;
                if (new Vector2(x - 16f, z - 616f).magnitude < 18f) return true;  // Pouce
                return NearRoad(x, z, 15f);
            };

            // Arbres (fusionnés en quelques meshes)
            var trees = new Dictionary<string, List<CombineInstance>>();
            string[] leaves = { "Leaves1", "Leaves2", "Leaves3" };
            int placed = 0;
            for (int tries = 0; tries < 6000 && placed < 450; tries++)
            {
                float x = R(-200f, 280f), z = R(-120f, 990f);
                if (Blocked(x, z)) continue;
                float h = R(3f, 6f), s = R(3.5f, 6.5f);
                var basePos = new Vector3(x, 0, z);
                AddCombined(trees, "Bark", cylMesh, Matrix4x4.TRS(basePos + Vector3.up * h * 0.5f, Quaternion.identity, new Vector3(0.45f, h * 0.5f, 0.45f)));
                string lm = leaves[rng.Next(leaves.Length)];
                AddCombined(trees, lm, sphereMesh, Matrix4x4.TRS(basePos + Vector3.up * (h + s * 0.25f), Quaternion.Euler(0, R(0, 360), 0), new Vector3(s, s * 0.85f, s)));
                AddCombined(trees, lm, sphereMesh, Matrix4x4.TRS(basePos + new Vector3(R(-1, 1), h + s * 0.6f, R(-1, 1)), Quaternion.identity, Vector3.one * s * 0.65f));
                placed++;
            }
            // arbres sur le rond-point
            for (int k = 0; k < 6; k++)
            {
                float ang = k * Mathf.PI / 3f;
                var bp = StatueCenter + new Vector3(Mathf.Cos(ang), 0, Mathf.Sin(ang)) * 13f;
                AddCombined(trees, "Bark", cylMesh, Matrix4x4.TRS(bp + Vector3.up * 2f, Quaternion.identity, new Vector3(0.35f, 2f, 0.35f)));
                AddCombined(trees, "Leaves2", sphereMesh, Matrix4x4.TRS(bp + Vector3.up * 5f, Quaternion.identity, Vector3.one * 3.5f));
            }
            FlushCombined(trees, "Arbres", parent);

            // Lampadaires le long de la route
            var lamps = new Dictionary<string, List<CombineInstance>>();
            for (int i = 0; i < path.Count; i += 28)
            {
                if (ZoneAt(path.p[i]) != Zone.Normal) continue;
                int side = (i / 28) % 2 == 0 ? 1 : -1;
                Vector3 bp = path.p[i] + path.right[i] * side * (RoadHalf + CurbW + BarrierT + 1.5f);
                bp.y = 0f;
                AddCombined(lamps, "DarkMetal", cylMesh, Matrix4x4.TRS(bp + Vector3.up * 3.5f, Quaternion.identity, new Vector3(0.2f, 3.5f, 0.2f)));
                AddCombined(lamps, "DarkMetal", cubeMesh, Matrix4x4.TRS(bp + Vector3.up * 7f - path.right[i] * side * 1.2f,
                    Quaternion.LookRotation(path.right[i]), new Vector3(0.15f, 0.15f, 2.6f)));
                AddCombined(lamps, "LampHead", sphereMesh, Matrix4x4.TRS(bp + Vector3.up * 6.8f - path.right[i] * side * 2.3f, Quaternion.identity, Vector3.one * 0.6f));
            }
            FlushCombined(lamps, "Lampadaires", parent);

            // Tours de La Défense en arrière-plan
            var towers = new MB();
            int nt = 0;
            for (int tries = 0; tries < 400 && nt < 34; tries++)
            {
                float x, z;
                if (nt < 20) { x = R(230f, 430f); z = R(420f, 960f); }
                else if (nt < 28) { x = R(-260f, -140f); z = R(560f, 960f); }
                else { x = R(-200f, 220f); z = R(970f, 1060f); }
                float w = R(18f, 36f), d = R(18f, 36f), h = R(55f, 175f);
                if (NearRoad(x, z, 60f)) continue;
                towers.Box(new Vector3(x - w / 2, 0, z - d / 2), new Vector3(x + w / 2, h, z + d / 2), 12f, false);
                nt++;
            }
            MeshGO("Tours_LaDefense", parent, towers, "Glass", false);
        }

        // ------------------------------------------------------------------ kart

        static KartController BuildKart(Vector3 pos, Quaternion rot)
        {
            var kartGO = new GameObject("Kart_Joueur");
            kartGO.transform.SetPositionAndRotation(pos, rot);
            var rb = kartGO.AddComponent<Rigidbody>();
            rb.mass = 150f;

            var pm = AssetDatabase.LoadAssetAtPath<PhysicsMaterial>(GenFolder + "/Materials/KartPhysics.asset");
            if (pm == null)
            {
                pm = new PhysicsMaterial("KartPhysics")
                {
                    dynamicFriction = 0f, staticFriction = 0f, bounciness = 0.05f,
                    frictionCombine = PhysicsMaterialCombine.Minimum,
                    bounceCombine = PhysicsMaterialCombine.Minimum
                };
                AssetDatabase.CreateAsset(pm, GenFolder + "/Materials/KartPhysics.asset");
            }
            var cap = kartGO.AddComponent<CapsuleCollider>();
            cap.direction = 2; cap.center = new Vector3(0, 0.35f, 0); cap.radius = 0.35f; cap.height = 2.0f; cap.sharedMaterial = pm;
            var box = kartGO.AddComponent<BoxCollider>();
            box.center = new Vector3(0, 0.8f, 0); box.size = new Vector3(1.3f, 0.5f, 1.9f); box.sharedMaterial = pm;

            var vis = new GameObject("Visuel").transform;
            vis.SetParent(kartGO.transform, false);
            Prim(PrimitiveType.Cube, "Chassis", vis, new Vector3(0, 0.4f, 0), new Vector3(1.3f, 0.3f, 2.0f), "KartBody");
            Prim(PrimitiveType.Cube, "Nez", vis, new Vector3(0, 0.45f, 1.05f), new Vector3(1.0f, 0.25f, 0.4f), "KartBody");
            Prim(PrimitiveType.Cube, "Aileron", vis, new Vector3(0, 0.95f, -0.95f), new Vector3(1.4f, 0.08f, 0.35f), "KartBody");
            Prim(PrimitiveType.Cube, "Siege", vis, new Vector3(0, 0.75f, -0.35f), new Vector3(0.6f, 0.5f, 0.15f), "DarkMetal");
            Prim(PrimitiveType.Cylinder, "Volant", vis, new Vector3(0, 0.95f, 0.45f), new Vector3(0.45f, 0.03f, 0.45f), "DarkMetal", Quaternion.Euler(-60, 0, 0));
            Prim(PrimitiveType.Capsule, "Pilote", vis, new Vector3(0, 1.05f, -0.15f), new Vector3(0.55f, 0.45f, 0.45f), "Driver");
            Prim(PrimitiveType.Sphere, "Casque", vis, new Vector3(0, 1.6f, -0.12f), Vector3.one * 0.45f, "White");
            foreach (var wpos in new[] { new Vector2(-0.72f, 0.7f), new Vector2(0.72f, 0.7f), new Vector2(-0.75f, -0.7f), new Vector2(0.75f, -0.7f) })
                Prim(PrimitiveType.Cylinder, "Roue", vis, new Vector3(wpos.x, 0.3f, wpos.y), new Vector3(0.6f, 0.17f, 0.6f), "Tire", Quaternion.Euler(0, 0, 90));

            var anchor = new GameObject("CameraAnchor_VR").transform;
            anchor.SetParent(kartGO.transform, false);
            anchor.localPosition = new Vector3(0, 1.55f, -0.1f);

            var plumeHolder = new GameObject("Objet_Plume").transform;
            plumeHolder.SetParent(kartGO.transform, false);
            var plume = PlaceFit("Plume", plumeHolder, kartGO.transform.TransformPoint(new Vector3(0, 2.1f, 0)), 0f, 0.7f);
            plume.transform.SetParent(plumeHolder, true);
            plumeHolder.gameObject.AddComponent<Spinner>().degreesPerSecond = new Vector3(0, 120, 0);
            plumeHolder.gameObject.SetActive(false);

            foreach (var t in kartGO.GetComponentsInChildren<Transform>(true)) t.gameObject.layer = 2; // Ignore Raycast
            foreach (var c in plumeHolder.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);

            var kc = kartGO.AddComponent<KartController>();
            kc.visual = vis;
            kc.plumeDisplay = plumeHolder.gameObject;
            kc.cameraAnchor = anchor;
            return kc;
        }

        static void SetupCameraAndLighting(Transform kart)
        {
            var cam = Camera.main;
            if (cam == null)
            {
                var cg = new GameObject("Main Camera") { tag = "MainCamera" };
                cam = cg.AddComponent<Camera>();
                cg.AddComponent<AudioListener>();
            }
            cam.farClipPlane = 2500f;
            cam.nearClipPlane = 0.1f;
            cam.transform.SetPositionAndRotation(kart.position + new Vector3(0, 2.6f, -6.5f), Quaternion.Euler(12, 0, 0));
            var kc = cam.gameObject.AddComponent<KartCamera>();
            kc.target = kart;

            var sunGO = GameObject.Find("Directional Light");
            var sun = sunGO ? sunGO.GetComponent<Light>() : null;
            if (sun != null)
            {
                sun.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
                sun.intensity = 1.25f;
                sun.shadows = LightShadows.Soft;
                sun.color = new Color(1f, 0.96f, 0.9f);
            }
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 300f;
            RenderSettings.fogEndDistance = 1800f;
            RenderSettings.fogColor = new Color(0.72f, 0.8f, 0.9f);
        }

        static void AddSceneToBuild(string path)
        {
            var scenes = EditorBuildSettings.scenes.ToList();
            if (scenes.All(s => s.path != path)) scenes.Insert(0, new EditorBuildSettingsScene(path, true));
            EditorBuildSettings.scenes = scenes.ToArray();
        }

        // ------------------------------------------------------------------ textures & matériaux

        static int Mod(int a, int m) { int r = a % m; return r < 0 ? r + m : r; }

        static float Hash(int x, int y, int seed)
        {
            unchecked
            {
                uint h = (uint)(x * 374761393 + y * 668265263 + seed * 1442695041);
                h = (h ^ (h >> 13)) * 1274126177u;
                h ^= h >> 16;
                return (h & 0xFFFFFF) / 16777215f;
            }
        }

        static float VNoise(float x, float y, int period, int seed)
        {
            int xi = Mathf.FloorToInt(x), yi = Mathf.FloorToInt(y);
            float fx = x - xi, fy = y - yi;
            fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
            int x0 = Mod(xi, period), x1 = Mod(xi + 1, period), y0 = Mod(yi, period), y1 = Mod(yi + 1, period);
            return Mathf.Lerp(Mathf.Lerp(Hash(x0, y0, seed), Hash(x1, y0, seed), fx),
                              Mathf.Lerp(Hash(x0, y1, seed), Hash(x1, y1, seed), fx), fy);
        }

        static float Fbm(float u, float v, int basePeriod, int oct, int seed)
        {
            float sum = 0, amp = 1, norm = 0; int p = basePeriod;
            for (int o = 0; o < oct; o++) { sum += VNoise(u * p, v * p, p, seed + o * 17) * amp; norm += amp; amp *= 0.5f; p *= 2; }
            return sum / norm;
        }

        static Texture2D Tex(string name, int w, int h, System.Func<float, float, int, int, Color> f)
        {
            string path = $"{GenFolder}/Textures/{name}.png";
            var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
            var px = new Color[w * h];
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                px[y * w + x] = f((x + 0.5f) / w, (y + 0.5f) / h, x, y);
            t.SetPixels(px);
            t.Apply();
            File.WriteAllBytes(path, t.EncodeToPNG());
            Object.DestroyImmediate(t);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            var imp = (TextureImporter)AssetImporter.GetAtPath(path);
            imp.wrapMode = TextureWrapMode.Repeat;
            imp.mipmapEnabled = true;
            imp.anisoLevel = 8;
            imp.filterMode = FilterMode.Trilinear;
            imp.SaveAndReimport();
            return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }

        static Material Mat(string name, Color c, Texture2D tex = null, float smooth = 0.3f, float metal = 0f, Color? emission = null, Texture2D emisTex = null)
        {
            string path = $"{GenFolder}/Materials/{name}.mat";
            var sh = Shader.Find("Universal Render Pipeline/Lit");
            var m = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (m == null) { m = new Material(sh); AssetDatabase.CreateAsset(m, path); }
            else m.shader = sh;
            m.SetColor("_BaseColor", c);
            m.SetTexture("_BaseMap", tex);
            m.SetFloat("_Smoothness", smooth);
            m.SetFloat("_Metallic", metal);
            if (emission.HasValue)
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", emission.Value);
                if (emisTex) m.SetTexture("_EmissionMap", emisTex);
                m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            }
            else
            {
                m.DisableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", Color.black);
            }
            m.enableInstancing = true;
            EditorUtility.SetDirty(m);
            M[name] = m;
            return m;
        }

        static void CreateMaterials()
        {
            var asphalt = Tex("asphalt", 512, 512, (u, v, x, y) =>
            {
                float n = Fbm(u, v, 8, 5, 1);
                float speck = Hash(x, y, 7) > 0.985f ? 0.12f : 0f;
                float g = 0.2f + n * 0.13f + speck;
                Color c = new Color(g, g, g * 1.04f);
                bool edge = (u > 0.035f && u < 0.06f) || (u > 0.94f && u < 0.965f);
                bool dash = Mathf.Abs(u - 0.5f) < 0.009f && v < 0.5f;
                if (edge || dash) c = Color.Lerp(c, new Color(0.92f, 0.92f, 0.9f), 0.9f);
                return c;
            });
            var curb = Tex("curb", 64, 64, (u, v, x, y) => v < 0.5f ? new Color(0.85f, 0.08f, 0.08f) : new Color(0.95f, 0.95f, 0.95f));
            var barrier = Tex("barrier", 128, 64, (u, v, x, y) =>
            {
                if (v > 0.85f) return new Color(1f, 0.82f, 0.1f);
                return u < 0.5f ? new Color(0.1f, 0.35f, 0.95f) : new Color(0.96f, 0.96f, 0.96f);
            });
            var grass = Tex("grass", 512, 512, (u, v, x, y) =>
            {
                float n = Fbm(u, v, 4, 5, 3), b = Hash(x, y, 11);
                return new Color(0.2f + n * 0.12f, 0.45f + n * 0.2f + b * 0.06f, 0.12f + n * 0.06f);
            });
            var stone = Tex("stone", 512, 512, (u, v, x, y) =>
            {
                int row = y / 64;
                int bx = (x + (row % 2) * 64) / 128;
                bool mortar = y % 64 < 4 || (x + (row % 2) * 64) % 128 < 4;
                float tint = Hash(bx, row, 5) * 0.12f;
                float n = Fbm(u, v, 8, 4, 9) * 0.15f;
                if (mortar) return new Color(0.62f, 0.6f, 0.56f);
                return new Color(0.72f + tint + n, 0.66f + tint + n, 0.55f + tint * 0.8f + n);
            });
            var tiles = Tex("tiles", 256, 256, (u, v, x, y) =>
            {
                bool line = x % 64 < 2 || y % 64 < 2;
                float n = Fbm(u, v, 4, 3, 13) * 0.06f;
                return line ? new Color(0.55f, 0.56f, 0.6f) : new Color(0.84f + n, 0.85f + n, 0.88f + n);
            });
            var concrete = Tex("concrete", 512, 512, (u, v, x, y) =>
            {
                bool joint = x % 256 < 3 || y % 256 < 3;
                float n = Fbm(u, v, 8, 5, 21);
                float g = 0.58f + n * 0.12f;
                return joint ? new Color(0.45f, 0.45f, 0.45f) : new Color(g, g, g * 1.02f);
            });
            var checker = Tex("checker", 64, 64, (u, v, x, y) => ((x / 32) + (y / 32)) % 2 == 0 ? Color.white : new Color(0.05f, 0.05f, 0.05f));
            var water = Tex("water", 256, 256, (u, v, x, y) =>
            {
                float n = Fbm(u, v, 4, 5, 31);
                float rip = Mathf.Pow(Mathf.Abs(Mathf.Sin((v * 8f + n * 3f) * Mathf.PI)), 12f) * 0.25f;
                return new Color(0.1f + rip, 0.32f + n * 0.12f + rip, 0.48f + n * 0.15f + rip);
            });
            var rainbow = Tex("rainbow", 256, 256, (u, v, x, y) =>
            {
                Color c = Color.HSVToRGB(Mathf.Repeat(u + v * 0.5f, 1f), 0.7f, 1f);
                bool border = u < 0.06f || u > 0.94f || v < 0.06f || v > 0.94f;
                return border ? Color.white : c;
            });
            var boost = Tex("boost", 128, 256, (u, v, x, y) =>
            {
                float s = Mathf.Repeat(v * 3f - Mathf.Abs(u - 0.5f) * 1.6f, 1f);
                bool border = u < 0.05f || u > 0.95f;
                return border ? new Color(0.2f, 0.2f, 0.2f) : (s < 0.4f ? new Color(1f, 0.92f, 0.2f) : new Color(1f, 0.45f, 0.05f));
            });
            var chevron = Tex("chevron", 256, 128, (u, v, x, y) =>
            {
                float s = Mathf.Repeat(u * 3f - Mathf.Abs(v - 0.5f) * 1.8f, 1f);
                bool border = v < 0.06f || v > 0.94f;
                return border ? Color.white : (s > 0.55f && s < 0.85f ? Color.white : new Color(0.85f, 0.08f, 0.08f));
            });
            var hallWall = Tex("hallwall", 256, 256, (u, v, x, y) =>
            {
                float n = Fbm(u, v, 4, 3, 41) * 0.05f;
                if (v > 0.30f && v < 0.36f) return new Color(0.05f, 0.42f, 0.75f);
                if (v > 0.37f && v < 0.39f) return new Color(0.98f, 0.73f, 0.1f);
                return new Color(0.9f + n, 0.9f + n, 0.92f + n);
            });
            var glass = Tex("glass", 256, 256, (u, v, x, y) =>
            {
                bool frame = x % 32 < 3 || y % 42 < 4;
                float lit = Hash(x / 32, y / 42, 51) > 0.8f ? 0.15f : 0f;
                return frame ? new Color(0.55f, 0.58f, 0.62f) : new Color(0.25f + lit, 0.38f + lit, 0.5f + lit);
            });

            Mat("Asphalt", Color.white, asphalt, 0.25f);
            Mat("Curb", Color.white, curb, 0.35f);
            Mat("Barrier", Color.white, barrier, 0.45f);
            Mat("Grass", Color.white, grass, 0.05f);
            Mat("Stone", Color.white, stone, 0.1f);
            Mat("Tiles", Color.white, tiles, 0.7f);
            Mat("Concrete", Color.white, concrete, 0.15f);
            Mat("Checker", Color.white, checker, 0.2f);
            Mat("Water", new Color(0.8f, 0.9f, 1f), water, 0.93f, 0.1f);
            Mat("Rainbow", Color.white, rainbow, 0.8f, 0f, new Color(0.6f, 0.6f, 0.6f), rainbow);
            Mat("Boost", Color.white, boost, 0.5f, 0f, new Color(0.8f, 0.5f, 0.1f), boost);
            Mat("Chevron", Color.white, chevron, 0.3f);
            Mat("HallWall", Color.white, hallWall, 0.3f);
            Mat("Glass", Color.white, glass, 0.88f, 0.5f);
            Mat("Brand", new Color(0.05f, 0.3f, 0.6f), null, 0.5f, 0.3f);
            Mat("DarkMetal", new Color(0.18f, 0.19f, 0.21f), null, 0.6f, 0.8f);
            Mat("White", new Color(0.95f, 0.95f, 0.95f), null, 0.4f);
            Mat("LampHead", new Color(1f, 0.95f, 0.8f), null, 0.5f, 0f, new Color(2f, 1.8f, 1.3f));
            Mat("LightPanel", Color.white, null, 0.5f, 0f, new Color(3f, 3f, 2.8f));
            Mat("StartLight", new Color(0.1f, 0.1f, 0.1f), null, 0.8f, 0f, Color.black);
            Mat("Bark", new Color(0.36f, 0.25f, 0.16f), null, 0.1f);
            Mat("Leaves1", new Color(0.2f, 0.5f, 0.18f), null, 0.1f);
            Mat("Leaves2", new Color(0.28f, 0.58f, 0.2f), null, 0.1f);
            Mat("Leaves3", new Color(0.16f, 0.42f, 0.2f), null, 0.1f);
            Mat("KartBody", new Color(0.85f, 0.1f, 0.12f), null, 0.75f, 0.3f);
            Mat("Tire", new Color(0.06f, 0.06f, 0.06f), null, 0.2f);
            Mat("Driver", new Color(0.1f, 0.35f, 0.85f), null, 0.3f);
            Mat("Missing", new Color(1f, 0f, 1f), null, 0.2f);
            AssetDatabase.SaveAssets();
        }
    }
}
